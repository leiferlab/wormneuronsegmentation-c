Optimized code for segmentation of neurons.

export LD_LIBRARY_PATH=/home/frandi/.local/lib64
